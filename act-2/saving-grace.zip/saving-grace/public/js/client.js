


// WARNING: ALL VERY BRUTE FORCE... SORRY! MY PEA-BRAIN JUST CAN'T TAKE IT RIGHT NOW!



$(function () {

    var socket = io();

    // USER COUNT

    // box1.mousedown(function(){
        // console.log('Mousedown over Box #1');
        socket.emit('disconnect', 'yes');
    // })

    // socket.on('connection', function(clients){
    //     console.log(clients + 'NUMBER OF CLIENTS');
    // })

    socket.on('disconnect', function(clients){
        console.log(clients + 'NUMBER OF CLIENTS');
    })


// DRAW DIV WHEN MOVING CURSOR https://stackoverflow.com/questions/3385936/jquery-follow-the-cursor-with-a-div

    // DRAW CURSORS 

    // $(document).mousemove(function(){
    //     socket.emit('cursor', 'yes');
    // })

    // socket.on('cursor', function(e){
    //     $('.square').css({
    //        left: e.pageX,
    //        top: e.pageY
    //     });
    //     console.log(e.pageX + ', ' + e.pageY)
    // })

    var audio1 = $('#audio1');
    var audio2 = $('#audio2');
    var audio3 = $('#audio3');
    var audio4 = $('#audio4');
    var audio5 = $('#audio5');
    var audio6 = $('#audio6');

    var box1 = $('#box1');
    var box2 = $('#box2');
    var box3 = $('#box3');
    var box4 = $('#box4');
    var box5 = $('#box5');
    var box6 = $('#box6');


/// FADE AUDIO VOLUME https://stackoverflow.com/questions/39511353/play-pause-music-with-fade-in-fade-out-with-javascript?rq=1

/// CLEAR ANIMATION QUEUE BUILD UP CAUSED BY HOLDING MOUSE DOWN https://stackoverflow.com/questions/14613498/how-to-prevent-this-strange-jquery-animate-lag


    // MOUSE DOWN

    box1.mousedown(function(){
        console.log('Mousedown over Box #1');
        socket.emit('down1', 'yes');
    })
    box2.mousedown(function(){
        console.log('Mousedown over Box #2');
        socket.emit('down2', 'yes');
    })
    box3.mousedown(function(){
        console.log('Mousedown over Box #3');
        socket.emit('down3', 'yes');
    })
    box4.mousedown(function(){
        console.log('Mousedown over Box #4');
        socket.emit('down4', 'yes');
    })
    box5.mousedown(function(){
        console.log('Mousedown over Box #5');
        socket.emit('down5', 'yes');
    })
    box6.mousedown(function(){
        console.log('Mousedown over Box #6');
        socket.emit('down6', 'yes');
    })


    socket.on('down1', function(){
        audio1.stop().animate({volume: 0.001}, 1800, function() {
            audio1.toggle('fast', function (){
                audio1.animate({volume: 0.001}); 
            })
        })
        box1.css({'background-color':'black'});
        console.log('Mousedown over Box #1');
    })
    socket.on('down2', function(){
        audio2.stop().animate({volume: 0.001}, 1800, function() {
            audio2.toggle('fast', function (){
                audio2.animate({volume: 0.001}); 
            })
        })
        box2.css({'background-color':'black'});
        console.log('Mousedown over Box #2');
    })
    socket.on('down3', function(){
        audio3.stop().animate({volume: 0.001}, 1800, function() {
            audio3.toggle('fast', function (){
                audio3.animate({volume: 0.001}); 
            })
        })
        box3.css({'background-color':'black'});
        console.log('Mousedown over Box #3');
    })
    socket.on('down4', function(){
        audio4.stop().animate({volume: 0.001}, 1800, function() {
            audio4.toggle('fast', function (){
                audio4.animate({volume: 0.001}); 
            })
        })
        box4.css({'background-color':'black'});
        console.log('Mousedown over Box #4');
    })
    socket.on('down5', function(){
        audio5.stop().animate({volume: 0.001}, 1800, function() {
            audio5.toggle('fast', function (){
                audio5.animate({volume: 0.001}); 
            })
        })
        box5.css({'background-color':'black'});
        console.log('Mousedown over Box #5');
    })
    socket.on('down6', function(){
        audio6.stop().animate({volume: 0.001}, 1800, function() {
            audio6.toggle('fast', function (){
                audio6.animate({volume: 0.001}); 
            })
        })
        box6.css({'background-color':'black'});
        console.log('Mousedown over Box #6');
    })



    // MOUSE UP

    box1.mouseup(function(){
        console.log('Mousedown over Box #1');
        socket.emit('up1', 'yes');
    })
    box2.mouseup(function(){
        console.log('Mousedown over Box #2');
        socket.emit('up2', 'yes');
    })
    box3.mouseup(function(){
        console.log('Mousedown over Box #3');
        socket.emit('up3', 'yes');
    })
    box4.mouseup(function(){
        console.log('Mousedown over Box #4');
        socket.emit('up4', 'yes');
    })
    box5.mouseup(function(){
        console.log('Mousedown over Box #5');
        socket.emit('up5', 'yes');
    })
    box6.mouseup(function(){
        console.log('Mousedown over Box #6');
        socket.emit('up6', 'yes');
    })



    socket.on('up1', function(){
        audio1.stop().animate({volume: 1.0}, 1800, function() {
            audio1.toggle('fast', function (){
                audio1.animate({volume: 1.0}); 
            })
        })
        box1.css({'background-color':'white'});
        console.log('Mouseup over Box #1');
    })
    socket.on('up2', function(){
        audio2.stop().animate({volume: 1.0}, 1800, function() {
            audio2.toggle('fast', function (){
                audio2.animate({volume: 1.0}); 
            })
        })
        box2.css({'background-color':'white'});
        console.log('Mouseup over Box #2');
    })
    socket.on('up3', function(){
        audio3.stop().animate({volume: 1.0}, 1800, function() {
            audio3.toggle('fast', function (){
                audio3.animate({volume: 1.0}); 
            })
        })
        box3.css({'background-color':'white'});
        console.log('Mouseup over Box #3');
    })
    socket.on('up4', function(){
        audio4.stop().animate({volume: 1.0}, 1800, function() {
            audio4.toggle('fast', function (){
                audio4.animate({volume: 1.0}); 
            })
        })
        box4.css({'background-color':'white'});
        console.log('Mouseup over Box #4');
    })
    socket.on('up5', function(){
        audio5.stop().animate({volume: 1.0}, 1800, function() {
            audio5.toggle('fast', function (){
                audio5.animate({volume: 1.0}); 
            })
        })
        box5.css({'background-color':'white'});
        console.log('Mouseup over Box #5');
    })
    socket.on('up6', function(){
        audio6.stop().animate({volume: 1.0}, 1800, function() {
            audio6.toggle('fast', function (){
                audio6.animate({volume: 1.0}); 
            })
        })
        box6.css({'background-color':'white'});
        console.log('Mouseup over Box #6');
    })

});





