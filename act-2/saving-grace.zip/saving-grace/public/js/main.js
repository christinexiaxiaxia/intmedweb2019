



      var socket = io();



var graceInfo = {
  0 : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', 'Amazing grace', 'Amazing grace', 'Amazing grace', 'Amazing grace', 'Amazing grace', 'Amazing grace', 'Amazing Grace', 'New Britain', 'At the cross', 'Amazing grace', 'Amazing grace (Untitled) / (Unissued)', 'Amazing grace', 'Amazing grace'],
  1 : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', 'Carl Smith, Carter Sisters & Mother Maybell [Carter]', 'Willie Nelson, Geezenslaw Brothers, Jody Payne, David Allen Coe & C. J. Coe.', 'Johnny Cash', 'Golden Gate Quartet', 'Mighty Clouds of Joy', 'Mighty Clouds of Joy', 'Lemonheads', 'Boston Camerata', "Fiddlin' John Carson", 'Chet Atkins', 'The Byrds', 'Pipes and Drums and Military Band of the Royal Scots Dragoon Guards', 'Skeeter Davis'],
  2 : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '1 sound disc : analog, mono. ; 10 in.', '1 sound disc : analog, stereo. ; 12 in.', '1 sound disc : digital, stereo. ; 4 3/4 in.', 'N/A', '1 sound disc : analog, stereo. ; 12 in.', '1 sound disc : analog, stereo. ; 12 in.', '1 sound disc : digital, stereo ; 4 3/4 in.', '1 sound reel : analog, stereo ; 10 in. x 1/4 in.', '1 sound disc : analog, mono. ; 10 in.', '1 sound disc : analog, mono. ; 12 in.', '2 sound discs : digital, stereo. ; 4 3/4 in.', '1 sound disc : analog, stereo. ; 12 in.', '1 sound disc : analog, stereo. ; 12 in.'],
  3 : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', 'Columbia Records, 1952, monographic.', 'Columbia Records, 1976, monographic.', 'Columbia, 1990, monographic.', 'Columbia Records, monographic.', 'MCA Records, 1972.', 'Peacock Records, 1972.', 'Taang! Records, Auburndale, MA, 1992.', 'Recorded in the Collidge Auditourium, Library of Congrss, Washington, DC on April 25, 1986', 'Okeh Records, 1931, monographic.', 'RCA Victor, 1962, monographic.', 'Sony Music Entertainment, New York, 2000, monographic.', 'RCA Victor, 1971, monographic.', 'RCA Victor, 1972, monographic.']
}

var audioFiles = ['grace1.mp3','grace13.mp3','grace14.mp3','grace18.mp3','grace24.mp3','grace26.mp3'];
var i = 0;


// CREATE ELEMENTS

for (i = 0; i < 6; i++) {

  var newAudio = $('<audio id="audio' + (i + 1) + '" src="' + audioFiles[i] + '" preload="auto" loop ></audio>'); // TOOK OUT AUTOPLAY... FOR NOW?
  var newLayer = $('<div class="layer layer' + (i + 1) + '"></div');

  var title = graceInfo[0];
  var artist = graceInfo[1];
  var media = graceInfo[2];
  var publish = graceInfo[3];

  var newGraceInfo = $('<p class="grace-info"><span class="title">' + title[i] + ' //</span> <span class="artist">' + artist[i] + ' //</span> <span class="media">' + media[i] + ' //</span> <span class="publish">' + publish[i] + '</span></p>')

  $(".audio-wrapper").append(newAudio);
  $(".layer-wrapper").append(newLayer);
  $(".grace-info-wrapper").append(newGraceInfo);

}


// PRESS SPACE TO START

$(document).one('keydown', function(e) {
  if (e.which == 32) {
    console.log('Pressed SPACE');
    document.getElementById("audio1").play();
    document.getElementById("audio2").play();
    document.getElementById("audio3").play();
    document.getElementById("audio4").play();
    document.getElementById("audio5").play();
    document.getElementById("audio6").play();

    $('audio').animate({volume: 0.001}, 0);
    $('audio').animate({volume: 1.0}, 8000);

    $('body').css({'background': 'black'})
    $('.start-screen').css({'color':'white', 'opacity':'0'});
    $('.box').css({'cursor':'pointer'});
  }
})










