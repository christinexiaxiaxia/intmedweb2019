var express = require('express');

var app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);



app.use(express.static('public'))


io.on('connection', function(socket){

// COUNT NUMBER OF CONNECTED USERS https://github.com/socketio/socket.io/issues/3166

  var clients = null;
  clients++;
  // io.emit('connection', clients);
  console.log('a user connected');
  console.log("connected clients", clients);
  console.log("io.engine.clientsCount", io.engine.clientsCount);

  socket.on("disconnect", socket => {
    clients--;
    io.emit('disconnect', clients)
    console.log("user disconnected");
    console.log("disconnected clients", clients);
    console.log("io.engine.clientsCount", io.engine.clientsCount);
  });

  // DRAW CURSORS

  // socket.on('cursor', function(){
  //   io.emit('cursor');
  // })

  // PRESS SPACE TO START

  socket.on('start', function(){
    console.log('Background black, music playing');
    io.emit('start');
  });

  // MOUSE DOWN

  socket.on('down1', function(){
    io.emit('down1')
  })
  socket.on('down2', function(){
    io.emit('down2')
  })
  socket.on('down3', function(){
    io.emit('down3')
  })
  socket.on('down4', function(){
    io.emit('down4')
  })
  socket.on('down5', function(){
    io.emit('down5')
  })
  socket.on('down6', function(){
    io.emit('down6')
  })

  // MOUSE UP

  socket.on('up1', function(){
    io.emit('up1')
  })
  socket.on('up2', function(){
    io.emit('up2')
  })
  socket.on('up3', function(){
    io.emit('up3')
  })
  socket.on('up4', function(){
    io.emit('up4')
  })
  socket.on('up5', function(){
    io.emit('up5')
  })
  socket.on('up6', function(){
    io.emit('up6')
  })


});

http.listen(11116, function(){
  console.log('listening on *:11116');
});







